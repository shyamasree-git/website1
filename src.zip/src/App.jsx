import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Homepage from "./pages/Homepage";
import Contact from "./pages/Contact";
// import Mobile from "./pages/services/Mobile"; // example
// import Web from "./pages/services/Web"; // example

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/contact" element={<Contact />} />
        {/* <Route path="/services/web" element={<Web />} />
        <Route path="/services/mobile" element={<Mobile />} /> */}
      </Routes>
    </Router>
  );
};

export default App;
