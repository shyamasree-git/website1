import React from "react";
import logo from "../assets/images/logo_travlog.png";
import { useNavigate } from "react-router-dom";
import Menu from "../components/Menu";

const Homepage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div className="header flex justify-between items-center text-center p-5">
        <div onClick={() => navigate("/")}>
          <img src={logo} alt="page logo" />
        </div>
        <Menu />
      </div>
      <div>
        <h2>This is our homePage</h2>
      </div>
    </>
  );
};

export default Homepage;
