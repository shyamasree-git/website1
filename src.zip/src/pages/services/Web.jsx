import React from "react";

const Web = () => {
  return (
    <div>
      <h2>This is Web Page</h2>
    </div>
  );
};

export default Web;
