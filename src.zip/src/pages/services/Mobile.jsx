import React from "react";

const Mobile = () => {
  return (
    <div>
      <h2>This is Mobile page</h2>
    </div>
  );
};

export default Mobile;
