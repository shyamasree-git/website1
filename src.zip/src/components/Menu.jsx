import React, { useState } from "react";
import { Link } from "react-router-dom";

const Menu = () => {
  const [openDropdown, setOpenDropdown] = useState(null);
  const menuItems = [
    { label: "Home", path: "/" },
    {
      label: "Services",
      dropdown: [
        { label: "Web Development", path: "/services/web" },
        { label: "Mobile Apps", path: "/services/mobile" },
      ],
    },
    { label: "Contact", path: "/contact" },
  ];

  return (
    <ul className="flex space-x-6">
      {menuItems.map((item, index) => (
        <li
          key={index}
          className="relative"
          onClick={() => item.dropdown && setOpenDropdown(index)}
        >
          {item.dropdown ? (
            <button className="hover:text-blue-800">{item.label}</button>
          ) : (
            <Link to={item.path} className="hover:text-blue-800">
              {item.label}
            </Link>
          )}

          {item.dropdown && openDropdown === index && (
            <ul className="absolute left-5 mt-2 bg-white text-black rounded shadow-lg w-40">
              {item.dropdown.map((sub, subIndex) => (
                <li key={subIndex}>
                  <Link
                    to={sub.path}
                    className="block px-4 py-2 hover:bg-gray-200"
                  >
                    {sub.label}
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </li>
      ))}
    </ul>
  );
};

export default Menu;
